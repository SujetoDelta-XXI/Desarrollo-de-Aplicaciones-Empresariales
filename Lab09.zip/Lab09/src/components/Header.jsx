function Header() {
  return (
    <header className="bg-primary text-white p-3 mb-4">
      <div className="container">
        <h1>Mi Aplicación de Series</h1>
      </div>
    </header>
  )
}

export default Header;