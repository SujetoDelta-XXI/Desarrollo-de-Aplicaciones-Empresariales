import React from 'react';
import './Footer.css';
function Footer() {
  return (
    <footer>
      <p>© 2024 Grupo 03 - Laboratorio S09</p>
    </footer>
  );
}

export default Footer;