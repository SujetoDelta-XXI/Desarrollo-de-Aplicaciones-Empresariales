from django.contrib import admin
from .models import QuestionStat, QuizActivity

admin.site.register(QuestionStat)
admin.site.register(QuizActivity)
